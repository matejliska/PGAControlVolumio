# PGAControlVolumio
Volumio plugin for external volume control using PGA4311 via SPI.

## Download and install the plugin
```shell
wget https://github.com/matejliska/PGAControlVolumio.git
mkdir ./PGAControlVolumio
miniunzip PGAControlVolumio.zip -d ./PGAControlVolumio
cd ./PGAControlVolumio
volumio plugin install
```
## Enable the plugin
In volumio webUI, go in plugin section and enable it!
